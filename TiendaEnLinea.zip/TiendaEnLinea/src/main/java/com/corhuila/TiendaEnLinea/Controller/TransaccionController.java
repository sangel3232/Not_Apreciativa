package com.corhuila.TiendaEnLinea.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.corhuila.TiendaEnLinea.Colecctions.Transaccion;
import com.corhuila.TiendaEnLinea.Service.TransaccionService;

@RestController
@RequestMapping("/transaccion")
@CrossOrigin
public class TransaccionController {
    @Autowired
    private TransaccionService transaccionService;

    @GetMapping
    public List<Transaccion> getAll() {
        return transaccionService.getAll();
    }

    @GetMapping("/{id}")
    public Transaccion getTransaccionById(@PathVariable String id) {
        return transaccionService.getTransaccionById(id);
    }

    @PostMapping
    public Transaccion createTransaccion(@RequestBody Transaccion transaccion) {
        return transaccionService.createTransaccion(transaccion);
    }

    @PutMapping("/{id}")
    public Transaccion updateTransaccion(@PathVariable String id, @RequestBody Transaccion transaccion) {
        return transaccionService.updateTransaccion(transaccion);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        transaccionService.delete(id);
    }
}