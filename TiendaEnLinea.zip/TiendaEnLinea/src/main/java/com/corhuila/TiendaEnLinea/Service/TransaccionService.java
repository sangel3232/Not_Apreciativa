package com.corhuila.TiendaEnLinea.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.corhuila.TiendaEnLinea.Colecctions.Transaccion;
import com.corhuila.TiendaEnLinea.Repository.TransaccionRepository;

@Service
public class TransaccionService {
    @Autowired
    private TransaccionRepository transaccionRepository;

    public List<Transaccion> getAll(){
        return transaccionRepository.findAll();
    }

    public Transaccion getTransaccionById(String id) {
        return transaccionRepository.findById(id).orElse(null);
    }

    public Transaccion createTransaccion(Transaccion transaccion) {
        return transaccionRepository.save(transaccion);
    }

    public Transaccion updateTransaccion(Transaccion transaccion) {
        return transaccionRepository.save(transaccion);
    }

    public void delete(String id){
        transaccionRepository.deleteById(id);
    }
}
