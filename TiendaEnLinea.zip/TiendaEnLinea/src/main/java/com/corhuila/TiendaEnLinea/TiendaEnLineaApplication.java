package com.corhuila.TiendaEnLinea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaEnLineaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaEnLineaApplication.class, args);
	}

}
