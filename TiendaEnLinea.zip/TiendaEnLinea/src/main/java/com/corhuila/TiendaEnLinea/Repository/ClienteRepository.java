package com.corhuila.TiendaEnLinea.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.corhuila.TiendaEnLinea.Colecctions.Cliente;

@Repository
public interface ClienteRepository extends MongoRepository<Cliente, String> {}
